// Example menu data with images
const menuItems = [
    {
        name: 'CHICKEN BIRIYANI',
        description: 'Classic chicken biriyani with the traditional touch of the accurate spices',
        price: '229/-',
        image: 'images/biriyani.jpeg'
    },
    {
        name: 'PRAWNS BIRIYANI',
        description: 'Classic prawns biriyani with the traditional touch of the costal spices',
        price: '229/-',
        image: 'images/Prawns.jpeg'
    },
    {
        name: 'PANEER BIRIYANI',
        description: '(VEG) Pure Paneer Biriyani',
        price: '200/-',
        image:  'images/paneer.jpeg'
    },
    {
        name: 'CASHEW BIRIYANI',
        description: '(VEG) Pure Cashew Biriyani',
        price: '210/-',
        image:  'images/cashew.jpeg'
    },
    {
        name: 'CHEF SPL BIRIYANI',
        description: '(NON-VEG) Biriyani consisting signature secret dish',
        price: '255/-',
        image: 'images/secret.jpeg'
    },
    {
        name: 'CHEF SPL BIRIYANI',
        description: '(VEG) Biriyani consisting signature secret dish',
        price: '200/-',
        image: 'images/secret2.jpeg'
    },
    {
        name: 'STAR FISH BIRIYANI',
        description: '(NON-VEG) Biriyani with quality fish from the costal region of Andhra',
        price: '219/-',
        image: 'images/fish.jpeg'
    }
];

// Function to display menu items
function displayMenu(menu) {
    const menuContainer = document.getElementById('menu');
    menu.forEach(item => {
        // Create a new div element for each menu item
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('menu-item');

        // Add item details to the div
        itemDiv.innerHTML = `
            <img src="${item.image}" alt="${item.name}" class="item-image">
            <div class="item-details">
                <div class="item-name">${item.name}</div>
                <div class="item-description">${item.description}</div>
                <div class="item-price">${item.price}</div>
            </div>
        `;

        // Append the item div to the menu container
        menuContainer.appendChild(itemDiv);
    });
}

// Call the function to display the menu
displayMenu(menuItems);
